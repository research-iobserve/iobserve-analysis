package protocom.extension2;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.xml.bind.JAXB;

import org.eclipse.emf.common.util.EList;
import org.palladiosimulator.protocom.extensionpoint.PcmModelEntityVisitor;
import org.palladiosimulator.protocom.lang.GeneratedFile;
import org.palladiosimulator.protocom.lang.ICompilationUnit;
import org.palladiosimulator.protocom.lang.java.IJCompilationUnit;
import org.palladiosimulator.protocom.lang.java.IJMethod;
import org.palladiosimulator.protocom.traverse.framework.PcmRepresentative;

import protocom.extension.mapping.PcmCorrespondentMethod;
import protocom.extension.mapping.PcmEntity;
import protocom.extension.mapping.PcmEntityCorrespondent;
import protocom.extension.mapping.PcmMapping;
import protocom.extension.mapping.PcmOperationSignature;
import de.uka.ipd.sdq.pcm.core.entity.NamedElement;
import de.uka.ipd.sdq.pcm.repository.BasicComponent;
import de.uka.ipd.sdq.pcm.repository.CompositeDataType;
import de.uka.ipd.sdq.pcm.repository.DataType;
import de.uka.ipd.sdq.pcm.repository.Interface;
import de.uka.ipd.sdq.pcm.repository.OperationInterface;
import de.uka.ipd.sdq.pcm.repository.OperationSignature;
import de.uka.ipd.sdq.pcm.repository.Parameter;
import de.uka.ipd.sdq.pcm.repository.PrimitiveDataType;
import de.uka.ipd.sdq.pcm.repository.PrimitiveTypeEnum;
import de.uka.ipd.sdq.pcm.repository.ProvidedRole;
import de.uka.ipd.sdq.pcm.repository.Repository;
import de.uka.ipd.sdq.pcm.repository.RepositoryComponent;
import de.uka.ipd.sdq.pcm.repository.RequiredRole;
import de.uka.ipd.sdq.pcm.repository.Signature;
import de.uka.ipd.sdq.pcm.seff.ServiceEffectSpecification;

public class SimplePcmEntityVisitor implements PcmModelEntityVisitor {

	private final PcmMapping mapping = new PcmMapping();
	private static final String outMapping = "mapping.xml";
	
	@Override
	public String getId() {
		return "test.id";
	}

	@Override
	public <E extends NamedElement> void visit(final PcmRepresentative<E> entity) {
		// get the pcm entity 
		final E pcmEntity = entity.getPCMEntity();
		
		// get the pcm informations
		final Class<?>[] superClass = pcmEntity.getClass().getInterfaces();
		for(final Class<?> nextInterface:superClass){
			if(nextInterface==Repository.class){
				this.visit((Repository) pcmEntity);
			} 
			else if(nextInterface==OperationInterface.class){
				this.visit((OperationInterface)pcmEntity);
			}
			else if(nextInterface==BasicComponent.class){
				this.visit((BasicComponent)pcmEntity, entity);
			}
		}
	}
	
	
	
	private void visit(final Repository repository){
		final String name = repository.getEntityName();
		final String id = repository.getId();
		
		final EList<RepositoryComponent> components__Repository = repository.getComponents__Repository();
		for(final RepositoryComponent nextComponent:components__Repository){
			final String nextName = nextComponent.getEntityName();
			final String nextId = nextComponent.getId();
		}
		
		final EList<Interface> interfaces__Repository = repository.getInterfaces__Repository();
		for(final Interface nextInterface:interfaces__Repository){
			final String nextName = nextInterface.getEntityName();
			final String nextId = nextInterface.getId();
		}
	}
	
	private void visit(final OperationInterface opInterface){
		final String name = opInterface.getEntityName();
		final String id = opInterface.getId();
		
		
		final EList<OperationSignature> signatures__OperationInterface = opInterface.getSignatures__OperationInterface();
		
		// go through operation signatures
		for(final OperationSignature nextSignature:signatures__OperationInterface){
			final String sigName = nextSignature.getEntityName();
			final String sigId = nextSignature.getId();
			
			// go through parameters
			final EList<Parameter> parameters__OperationSignature = nextSignature.getParameters__OperationSignature();
			for(final Parameter nextParam:parameters__OperationSignature){
				final String paramName = nextParam.getParameterName();
				final String paramType = nextParam.getDataType__Parameter().toString();
			}
		}
	}
	
	private <E extends NamedElement> void visit(final BasicComponent basicComponent, final PcmRepresentative<E> entity){
		final PcmEntity pcmEntity = new PcmEntity();
		this.mapping.getEntities().add(pcmEntity);
		
		final String id = basicComponent.getId();
		final String name = basicComponent.getEntityName();
		
		pcmEntity.setName(name);
		pcmEntity.setId(id);
		
		final EList<ServiceEffectSpecification> serviceEffectSpecifications__BasicComponent = basicComponent.getServiceEffectSpecifications__BasicComponent();
		final EList<ProvidedRole> providedRoles_InterfaceProvidingEntity = basicComponent.getProvidedRoles_InterfaceProvidingEntity();
		final EList<RequiredRole> requiredRoles_InterfaceRequiringEntity = basicComponent.getRequiredRoles_InterfaceRequiringEntity();
		
		// go through provided role
		for(final ProvidedRole nextRole:providedRoles_InterfaceProvidingEntity){
			final String roleId = nextRole.getId();
			final String roleName = nextRole.getEntityName();
			System.out.println(roleName);
		}
		
		for(final RequiredRole nextRole:requiredRoles_InterfaceRequiringEntity){
			final String roleId = nextRole.getId();
			final String roleName = nextRole.getEntityName();
			System.out.println(roleName);
		}
		
		for(final ServiceEffectSpecification nextSeff:serviceEffectSpecifications__BasicComponent){
			final String seffId = nextSeff.getSeffTypeID();
			Signature describedService__SEFF = nextSeff.getDescribedService__SEFF();
			String entityName = describedService__SEFF.getEntityName();
			String id2 = describedService__SEFF.getId();
			
			final PcmOperationSignature pcmOpSig = new PcmOperationSignature();
			pcmOpSig.setSeffName(entityName);
			pcmEntity.getOperationSigs().add(pcmOpSig);
			
			if(describedService__SEFF instanceof OperationSignature){
				OperationSignature opsig = (OperationSignature) describedService__SEFF;
				String opEntityName = opsig.getEntityName();
				String opId = opsig.getId();
				
				pcmOpSig.setName(opEntityName);
				pcmOpSig.setId(opId);
				
				final EList<Parameter> parameters__OperationSignature = opsig.getParameters__OperationSignature();
				for(final Parameter nextParam:parameters__OperationSignature){
					final String paramName = nextParam.getParameterName();
					DataType dataType__Parameter = nextParam.getDataType__Parameter();
					if(dataType__Parameter instanceof PrimitiveDataType){
						PrimitiveDataType primDt = (PrimitiveDataType) dataType__Parameter;
						PrimitiveTypeEnum type = primDt.getType();
						System.out.println(type.getName());
						System.out.println(type.getLiteral());
					} else if(dataType__Parameter instanceof CompositeDataType){
						CompositeDataType compDt = (CompositeDataType)dataType__Parameter;
						final String compDtName = compDt.getEntityName();
						final String compDtId = compDt.getId();
						compDt.getInnerDeclaration_CompositeDataType();
					}
					System.out.println();
					System.out.println();
				}
			}
			

			System.out.println(seffId);
			System.out.println();
		}
		
		// map to the generated files
		this.mapBasicComponentToGeneratedFiles(pcmEntity, entity.getGeneratedFiles());
		
		// write output file
		final File outFile = new File(outMapping);
		JAXB.marshal(this.mapping, outFile.getAbsolutePath());
		System.out.println("Generated mapping out file at " + outFile.getAbsolutePath());
	}
	
	private void mapBasicComponentToGeneratedFiles(final PcmEntity pcmEntity,
		final List<GeneratedFile<? extends ICompilationUnit>> generatedFiles){
		
		for(final ICompilationUnit nextUnit : generatedFiles){
			PcmEntityCorrespondent pcmCorres = new PcmEntityCorrespondent();
			pcmCorres.setFilePath(nextUnit.filePath());
			pcmCorres.setProjectName(nextUnit.projectName());
			
			pcmEntity.getCorrespondents().add(pcmCorres);
			
			if(nextUnit instanceof IJCompilationUnit){
				final IJCompilationUnit jComp = (IJCompilationUnit) nextUnit;
				final String projectName = jComp.projectName();
				final String packageName = jComp.packageName();
				final String unitName = jComp.compilationUnitName();
				final Collection<String> interfaces = jComp.interfaces();
				
				pcmCorres.setUnitName(unitName);
				pcmCorres.setPackageName(packageName);
				pcmCorres.setProjectName(projectName);
				pcmCorres.setInterfaces(new ArrayList<>(interfaces));
				
				final Collection<? extends IJMethod> methods = jComp.methods();
				for(IJMethod nextMethod:methods){
					
					final PcmCorrespondentMethod pcmCorresMethod = new PcmCorrespondentMethod();
					
					pcmCorres.getMethods().add(pcmCorresMethod);
					
					String body = nextMethod.body();
					String methodAnnotation = nextMethod.methodAnnotation();
					String name = nextMethod.name();
					String string = nextMethod.toString();
					String parameters = nextMethod.parameters();
					String returnType = nextMethod.returnType();
					String visibilityModifier = nextMethod.visibilityModifier();
					System.out.println();
					
					pcmCorresMethod.setName(name);
					pcmCorresMethod.setParameters(parameters);
					pcmCorresMethod.setReturnType(returnType);
					pcmCorresMethod.setVisibilityModifier(visibilityModifier);
				}
			}
		}
	}
	
	
}
